"""Version information for pvl-p90-client package."""

__version__: str = "0.1.0.170+dev"
