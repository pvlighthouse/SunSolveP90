class P90ClientError(Exception):
    """Base exception for P90Client errors."""


class AuthenticationError(P90ClientError):
    """Raised when authentication fails."""


class P90ConnectionError(P90ClientError):
    """Raised when connection to the service fails."""


class ServiceError(P90ClientError):
    """Raised when the service returns an error."""


class TimeStepDataError(P90ClientError):
    """Raised when there is an error with time step data processing."""
